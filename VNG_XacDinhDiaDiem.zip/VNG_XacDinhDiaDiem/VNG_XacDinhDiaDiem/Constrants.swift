//
//  Constrants.swift
//  VNG_XacDinhDiaDiem
//
//  Created by TramTran on 12/1/15.
//  Copyright (c) 2015 TramTran. All rights reserved.
//

let googleMapAPIKey = "AIzaSyDb7TKH7nkQk2kepP-IQheTYj0XVqyzG0Y"
let googleMapAPIKey2 = "AIzaSyDBoXWZwWTDQRKHSBnJUtx9XlNFWnID1Zo"
let googleServerKey = "AIzaSyCPdpuVxqOLZSHfDtD7M8X7DaIiaOlenEc"

struct Data {
    
    static var placeNears:[PlaceNear]! = [] // mang chua placeNears de chuyen qua cho ViewPlaceNear
    static var placeDetail:Place? = nil
}
